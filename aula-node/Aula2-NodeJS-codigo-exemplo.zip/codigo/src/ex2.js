const express = require('express');
const app = express();

app.use('/saudacao',express.static('../public'));

//http://localhost:3001/teste.txt
app.listen(3001, function () {
    console.log("Servidor rodando na porta 3001...");
});