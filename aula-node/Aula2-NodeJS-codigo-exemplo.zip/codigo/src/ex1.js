const express = require('express'); //importa o módulo Express
const app = express(); //cria uma aplicação Express
app.use(express.json()); //para conversão de application/json
app.use(express.urlencoded({ extended: true })) // para conversão de application/x-www-form-urlencoded


//definição da rota para a raiz
//acesso usando http://localhost:3000/
app.get('/', function (req, res) {
    res.send('Raiz');
});

//acesso usando http://localhost:3000/cadastro/cliente
app.get('/cadastro/cliente', function (req, res) {
    res.send('caminho para cadastro/cliente');
});

//acesso usando http://localhost:3000/produto/arroz/10.99
app.get('/produto/:nome/:valor', function (req, res) {
    let nome = req.params.nome;
    let valor = req.params.valor;
    res.send('parâmetros ' + nome + ' ' + valor);
});

// curl -X GET -d "x=5&y=2" http://localhost:3000/valores
app.get('/valores', function (req, res) {
    //recebe os parâmetros enviados pelo corpo da requisição
    let { x, y } = req.body;
    res.send('GET ' + x + ' e ' + y);
});

// curl -X POST -d "x=5&y=2" http://localhost:3000/valores
app.post('/valores', function (req, res) {
    //recebe os parâmetros enviados pelo corpo da requisição
    let { x, y } = req.body;
    res.send('POST ' + x + ' e ' + y);
});

// curl -X POST -d "x=5&y=2" http://localhost:3000/valores/10
app.post('/valores/:w', function (req, res) {
    //recebe os parâmetros enviados pelo corpo da requisição
    let { x, y } = req.body;
    let w = req.params.w; //parâmetro enviado pela URL
    res.send('POST ' + x + ', ' + y + ' e ' + w);
});

//curl -X GET -d "x=1&y=2" http://localhost:3000/tudo
//curl -X POST -d "x=3&y=4" http://localhost:3000/tudo
//curl -X PUT -d "x=5&y=6" http://localhost:3000/tudo
//curl -X DELETE -d "x=7&y=8" http://localhost:3000/tudo
app.all('/tudo', function (req, res) {
    let { x, y } = req.body;
    res.send('ALL ' + x + ' e ' + y);
});

//aceita qualquer método HTTP ou URL iniciando por /inicio 
app.use('/inicio', function(req, res){
    res.send('URL com /inicio');
});

//aceita qualquer método HTTP e URL
app.use(function(req, res){
    res.send('URL desconhecida');
});

//define a porta e a função callback a ser executada após o servidor iniciar
app.listen(3000, function () {
    console.log("Servidor rodando na porta 3000...");
});